
/*

This tool is written by the model of valgrind tool Lackey

*/

#include "pub_tool_basics.h"
#include "pub_tool_tooliface.h"
#include "pub_tool_libcassert.h"
#include "pub_tool_libcprint.h"
#include "pub_tool_debuginfo.h"
#include "pub_tool_libcbase.h"
#include "pub_tool_options.h"
#include "pub_tool_machine.h"     // VG_(fnptr_to_fnentry)



static Bool clo_basic_counts = True;

// The extra function ,count the number of call of the target function 
// the comman line should has the option --fnname

static const HChar* clo_fnname = "main";

static Bool vf_process_cmd_line_option(const HChar* arg)
{
   if VG_STR_CLO(arg, "--fnname", clo_fnname) {}
//    else if VG_BOOL_CLO(arg, "--basic-counts",      clo_basic_counts) {}
//    else if VG_BOOL_CLO(arg, "--detailed-counts",   clo_detailed_counts) {}
//    else if VG_BOOL_CLO(arg, "--trace-mem",         clo_trace_mem) {}
//    else if VG_BOOL_CLO(arg, "--trace-superblocks", clo_trace_sbs) {}
   else
      return False;
   
   tl_assert(clo_fnname);
   tl_assert(clo_fnname[0]);
   return True;
}



static void vf_print_usage(void)
{  
   VG_(printf)(
"    --basic-counts=no|yes     count instructions, jumps, etc. [yes]\n"
// "    --detailed-counts=no|yes  count loads, stores and alu ops [no]\n"
// "    --trace-mem=no|yes        trace all loads and stores [no]\n"
// "    --trace-superblocks=no|yes  trace all superblock entries [no]\n"
 "    --fnname=<name>           count calls to <name> (only used if\n"
 "                              --basic-count=yes)  [main]\n"
   );
}


static void vf_print_debug_usage(void)
{  
   VG_(printf)(
"    (none)\n"
   );
}


/*------------------------------------------------------------*/
/*--- Stuff for --basic-counts                             ---*/
/*------------------------------------------------------------*/

/* Nb: use ULongs because the numbers can get very big */
static ULong n_func_calls    = 0;
static ULong n_SBs_entered   = 0;
static ULong n_SBs_completed = 0;
static ULong n_IRStmts       = 0;
static ULong n_guest_instrs  = 0;
static ULong n_Jccs          = 0;
static ULong n_Jccs_untaken  = 0;
static ULong n_IJccs         = 0;
static ULong n_IJccs_untaken = 0;

static void add_one_func_call(void)
{
   n_func_calls++;
}

static void add_one_SB_entered(void)
{
   n_SBs_entered++;
}

static void add_one_SB_completed(void)
{
   n_SBs_completed++;
}

static void add_one_IRStmt(void)
{
   n_IRStmts++;
}

static void add_one_guest_instr(void)
{
   n_guest_instrs++;
}

static void add_one_Jcc(void)
{
   n_Jccs++;
}

static void add_one_Jcc_untaken(void)
{
   n_Jccs_untaken++;
}

static void add_one_inverted_Jcc(void)
{
   n_IJccs++;
}

static void add_one_inverted_Jcc_untaken(void)
{
   n_IJccs_untaken++;
}




static
IRSB* vf_instrument ( VgCallbackClosure* closure,
                      IRSB* sbIn, 
                      const VexGuestLayout* layout, 
                      const VexGuestExtents* vge,
                      const VexArchInfo* archinfo_host,
                      IRType gWordTy, IRType hWordTy )
{
   IRDirty*   di;
   Int        i;
   IRSB*      sbOut;
   IRTypeEnv* tyenv = sbIn->tyenv;
   Addr       iaddr = 0, dst;
   UInt       ilen = 0;
   Bool       condition_inverted = False;
   DiEpoch    ep = VG_(current_DiEpoch)();

   if (gWordTy != hWordTy) {
      /* We don't currently support this case. */
      VG_(tool_panic)("host/guest word size mismatch");
   }

   /* Set up SB */
   sbOut = deepCopyIRSBExceptStmts(sbIn);

   // Copy verbatim any IR preamble preceding the first IMark
   i = 0;
   while (i < sbIn->stmts_used && sbIn->stmts[i]->tag != Ist_IMark) {
      addStmtToIRSB( sbOut, sbIn->stmts[i] );
      i++;
   }

   if (clo_basic_counts) {
      /* Count this superblock. */
      di = unsafeIRDirty_0_N( 0, "add_one_SB_entered", 
                                 VG_(fnptr_to_fnentry)( &add_one_SB_entered ),
                                 mkIRExprVec_0() );
      addStmtToIRSB( sbOut, IRStmt_Dirty(di) );
   }

//    if (clo_trace_sbs) {
//       /* Print this superblock's address. */
//       di = unsafeIRDirty_0_N( 
//               0, "trace_superblock", 
//               VG_(fnptr_to_fnentry)( &trace_superblock ),
//               mkIRExprVec_1( mkIRExpr_HWord( vge->base[0] ) ) 
//            );
//       addStmtToIRSB( sbOut, IRStmt_Dirty(di) );
//    }

//    if (clo_trace_mem) {
//       events_used = 0;
//    }

   for (/*use current i*/; i < sbIn->stmts_used; i++) {
      IRStmt* st = sbIn->stmts[i];
      if (!st || st->tag == Ist_NoOp) continue;

      if (clo_basic_counts) {
         /* Count one VEX statement. */
         di = unsafeIRDirty_0_N( 0, "add_one_IRStmt", 
                                    VG_(fnptr_to_fnentry)( &add_one_IRStmt ), 
                                    mkIRExprVec_0() );
         addStmtToIRSB( sbOut, IRStmt_Dirty(di) );
      }
      
      switch (st->tag) {
         case Ist_NoOp:
         case Ist_AbiHint:
         case Ist_Put:
         case Ist_PutI:
         case Ist_MBE:
            addStmtToIRSB( sbOut, st );
            break;

         case Ist_IMark:
            if (clo_basic_counts) {
               /* Needed to be able to check for inverted condition in Ist_Exit */
               iaddr = st->Ist.IMark.addr;
               ilen  = st->Ist.IMark.len;

               /* Count guest instruction. */
               di = unsafeIRDirty_0_N( 0, "add_one_guest_instr",
                                          VG_(fnptr_to_fnentry)( &add_one_guest_instr ), 
                                          mkIRExprVec_0() );
               addStmtToIRSB( sbOut, IRStmt_Dirty(di) );

               /* An unconditional branch to a known destination in the
                * guest's instructions can be represented, in the IRSB to
                * instrument, by the VEX statements that are the
                * translation of that known destination. This feature is
                * called 'SB chasing' and can be influenced by command
                * line option --vex-guest-chase=[yes|no].
                *
                * To get an accurate count of the calls to a specific
                * function, taking SB chasing into account, we need to
                * check for each guest instruction (Ist_IMark) if it is
                * the entry point of a function.
                */
               tl_assert(clo_fnname);
               tl_assert(clo_fnname[0]);
               const HChar *fnname;
               if (VG_(get_fnname_if_entry)(ep, st->Ist.IMark.addr,
                                            &fnname)
                   && 0 == VG_(strcmp)(fnname, clo_fnname)) {
                  di = unsafeIRDirty_0_N( 
                          0, "add_one_func_call", 
                             VG_(fnptr_to_fnentry)( &add_one_func_call ), 
                             mkIRExprVec_0() );
                  addStmtToIRSB( sbOut, IRStmt_Dirty(di) );
               }
            }
            if (clo_trace_mem) {
               // WARNING: do not remove this function call, even if you
               // aren't interested in instruction reads.  See the comment
               // above the function itself for more detail.
               addEvent_Ir( sbOut, mkIRExpr_HWord( (HWord)st->Ist.IMark.addr ),
                            st->Ist.IMark.len );
            }
            addStmtToIRSB( sbOut, st );
            break;

         case Ist_WrTmp:
            // Add a call to trace_load() if --trace-mem=yes.
            // if (clo_trace_mem) {
            //    IRExpr* data = st->Ist.WrTmp.data;
            //    if (data->tag == Iex_Load) {
            //       addEvent_Dr( sbOut, data->Iex.Load.addr,
            //                    sizeofIRType(data->Iex.Load.ty) );
            //    }
            // }
            // if (clo_detailed_counts) {
            //    IRExpr* expr = st->Ist.WrTmp.data;
            //    IRType  type = typeOfIRExpr(sbOut->tyenv, expr);
            //    tl_assert(type != Ity_INVALID);
            //    switch (expr->tag) {
            //       case Iex_Load:
            //         instrument_detail( sbOut, OpLoad, type, NULL/*guard*/ );
            //          break;
            //       case Iex_Unop:
            //       case Iex_Binop:
            //       case Iex_Triop:
            //       case Iex_Qop:
            //       case Iex_ITE:
            //          instrument_detail( sbOut, OpAlu, type, NULL/*guard*/ );
            //          break;
            //       default:
            //          break;
            //    }
            // }
            addStmtToIRSB( sbOut, st );
            break;

         case Ist_Store: {
            IRExpr* data = st->Ist.Store.data;
            IRType  type = typeOfIRExpr(tyenv, data);
            tl_assert(type != Ity_INVALID);
            // if (clo_trace_mem) {
            //    addEvent_Dw( sbOut, st->Ist.Store.addr,
            //                 sizeofIRType(type) );
            // }
            // if (clo_detailed_counts) {
            //    instrument_detail( sbOut, OpStore, type, NULL/*guard*/ );
            // }
            addStmtToIRSB( sbOut, st );
            break;
         }

         case Ist_StoreG: {
            IRStoreG* sg   = st->Ist.StoreG.details;
            IRExpr*   data = sg->data;
            IRType    type = typeOfIRExpr(tyenv, data);
            tl_assert(type != Ity_INVALID);
            // if (clo_trace_mem) {
            //    addEvent_Dw_guarded( sbOut, sg->addr,
            //                         sizeofIRType(type), sg->guard );
            // }
            // if (clo_detailed_counts) {
            //    instrument_detail( sbOut, OpStore, type, sg->guard );
            // }
            addStmtToIRSB( sbOut, st );
            break;
         }

         case Ist_LoadG: {
            IRLoadG* lg       = st->Ist.LoadG.details;
            IRType   type     = Ity_INVALID; /* loaded type */
            IRType   typeWide = Ity_INVALID; /* after implicit widening */
            typeOfIRLoadGOp(lg->cvt, &typeWide, &type);
            tl_assert(type != Ity_INVALID);
            // if (clo_trace_mem) {
            //    addEvent_Dr_guarded( sbOut, lg->addr,
            //                         sizeofIRType(type), lg->guard );
            // }
            // if (clo_detailed_counts) {
            //    instrument_detail( sbOut, OpLoad, type, lg->guard );
            // }
            addStmtToIRSB( sbOut, st );
            break;
         }

         case Ist_Dirty: {
            if (clo_trace_mem) {
               Int      dsize;
               IRDirty* d = st->Ist.Dirty.details;
               if (d->mFx != Ifx_None) {
                  // This dirty helper accesses memory.  Collect the details.
                  tl_assert(d->mAddr != NULL);
                  tl_assert(d->mSize != 0);
                  dsize = d->mSize;
                  if (d->mFx == Ifx_Read || d->mFx == Ifx_Modify)
                     addEvent_Dr( sbOut, d->mAddr, dsize );
                  if (d->mFx == Ifx_Write || d->mFx == Ifx_Modify)
                     addEvent_Dw( sbOut, d->mAddr, dsize );
               } else {
                  tl_assert(d->mAddr == NULL);
                  tl_assert(d->mSize == 0);
               }
            }
            addStmtToIRSB( sbOut, st );
            break;
         }

         case Ist_CAS: {
            /* We treat it as a read and a write of the location.  I
               think that is the same behaviour as it was before IRCAS
               was introduced, since prior to that point, the Vex
               front ends would translate a lock-prefixed instruction
               into a (normal) read followed by a (normal) write. */
            Int    dataSize;
            IRType dataTy;
            IRCAS* cas = st->Ist.CAS.details;
            tl_assert(cas->addr != NULL);
            tl_assert(cas->dataLo != NULL);
            dataTy   = typeOfIRExpr(tyenv, cas->dataLo);
            dataSize = sizeofIRType(dataTy);
            if (cas->dataHi != NULL)
               dataSize *= 2; /* since it's a doubleword-CAS */
            
            addStmtToIRSB( sbOut, st );
            break;
         }

         case Ist_LLSC: {
            IRType dataTy;
            if (st->Ist.LLSC.storedata == NULL) {
               /* LL */
               dataTy = typeOfIRTemp(tyenv, st->Ist.LLSC.result);
               if (clo_trace_mem) {
                  addEvent_Dr( sbOut, st->Ist.LLSC.addr,
                                      sizeofIRType(dataTy) );
                  /* flush events before LL, helps SC to succeed */
                  flushEvents(sbOut);
	       }
            //    if (clo_detailed_counts)
            //       instrument_detail( sbOut, OpLoad, dataTy, NULL/*guard*/ );
            // } else {
               /* SC */
               dataTy = typeOfIRExpr(tyenv, st->Ist.LLSC.storedata);
            //    if (clo_trace_mem)
            //       addEvent_Dw( sbOut, st->Ist.LLSC.addr,
            //                           sizeofIRType(dataTy) );
            //    if (clo_detailed_counts)
            //       instrument_detail( sbOut, OpStore, dataTy, NULL/*guard*/ );
            // }
            addStmtToIRSB( sbOut, st );
            break;
         }

         case Ist_Exit:
            if (clo_basic_counts) {
               // The condition of a branch was inverted by VEX if a taken
               // branch is in fact a fall trough according to client address
               tl_assert(iaddr != 0);
               dst = (sizeof(Addr) == 4) ? st->Ist.Exit.dst->Ico.U32 :
                                           st->Ist.Exit.dst->Ico.U64;
               condition_inverted = (dst == iaddr + ilen);

               /* Count Jcc */
               if (!condition_inverted)
                  di = unsafeIRDirty_0_N( 0, "add_one_Jcc", 
                                          VG_(fnptr_to_fnentry)( &add_one_Jcc ), 
                                          mkIRExprVec_0() );
               else
                  di = unsafeIRDirty_0_N( 0, "add_one_inverted_Jcc",
                                          VG_(fnptr_to_fnentry)(
                                             &add_one_inverted_Jcc ),
                                          mkIRExprVec_0() );

               addStmtToIRSB( sbOut, IRStmt_Dirty(di) );
            }
            // if (clo_trace_mem) {
            //    flushEvents(sbOut);
            // }

            addStmtToIRSB( sbOut, st );      // Original statement

            if (clo_basic_counts) {
               /* Count non-taken Jcc */
               if (!condition_inverted)
                  di = unsafeIRDirty_0_N( 0, "add_one_Jcc_untaken", 
                                          VG_(fnptr_to_fnentry)(
                                             &add_one_Jcc_untaken ),
                                          mkIRExprVec_0() );
               else
                  di = unsafeIRDirty_0_N( 0, "add_one_inverted_Jcc_untaken",
                                          VG_(fnptr_to_fnentry)(
                                             &add_one_inverted_Jcc_untaken ),
                                          mkIRExprVec_0() );

               addStmtToIRSB( sbOut, IRStmt_Dirty(di) );
            }
            break;

         default:
            ppIRStmt(st);
            tl_assert(0);
      }
   }

   if (clo_basic_counts) {
      /* Count this basic block. */
      di = unsafeIRDirty_0_N( 0, "add_one_SB_completed", 
                                 VG_(fnptr_to_fnentry)( &add_one_SB_completed ),
                                 mkIRExprVec_0() );
      addStmtToIRSB( sbOut, IRStmt_Dirty(di) );
   }

//    if (clo_trace_mem) {
//       /* At the end of the sbIn.  Flush outstandings. */
//       flushEvents(sbOut);
//    }

   return sbOut;
}





static void vf_fini(Int exitcode)
{
   tl_assert(clo_fnname);
   tl_assert(clo_fnname[0]);

   if (clo_basic_counts) {
      ULong total_Jccs = n_Jccs + n_IJccs;
      ULong taken_Jccs = (n_Jccs - n_Jccs_untaken) + n_IJccs_untaken;

      VG_(umsg)("Counted %'llu call%s to %s()\n",
                n_func_calls, ( n_func_calls==1 ? "" : "s" ), clo_fnname);

      VG_(umsg)("\n");
      VG_(umsg)("Jccs:\n");
      VG_(umsg)("  total:         %'llu\n", total_Jccs);
      VG_(umsg)("  taken:         %'llu (%.0f%%)\n",
                taken_Jccs, taken_Jccs * 100.0 / (total_Jccs ? total_Jccs : 1));
      
//       VG_(umsg)("\n");
//       VG_(umsg)("Executed:\n");
//       VG_(umsg)("  SBs entered:   %'llu\n", n_SBs_entered);
//       VG_(umsg)("  SBs completed: %'llu\n", n_SBs_completed);
//       VG_(umsg)("  guest instrs:  %'llu\n", n_guest_instrs);
//       VG_(umsg)("  IRStmts:       %'llu\n", n_IRStmts);
      
//       VG_(umsg)("\n");
//       VG_(umsg)("Ratios:\n");
//       tl_assert(n_SBs_entered); // Paranoia time.
//       VG_(umsg)("  guest instrs : SB entered  = %'llu : 10\n",
//          10 * n_guest_instrs / n_SBs_entered);
//       VG_(umsg)("       IRStmts : SB entered  = %'llu : 10\n",
//          10 * n_IRStmts / n_SBs_entered);
//       tl_assert(n_guest_instrs); // Paranoia time.
//       VG_(umsg)("       IRStmts : guest instr = %'llu : 10\n",
//          10 * n_IRStmts / n_guest_instrs);
//    }

//    if (clo_detailed_counts) {
//       VG_(umsg)("\n");
//       VG_(umsg)("IR-level counts by type:\n");
//       print_details();
//    }

   if (clo_basic_counts) {
      VG_(umsg)("\n");
      VG_(umsg)("Exit code:       %d\n", exitcode);
   }
}

static void vf_pre_clo_init(void)
{
   VG_(details_name)            ("VFuzz");
   VG_(details_version)         ("0.0");
   VG_(details_description)     ("Aim to count the jccs");
   VG_(details_copyright_author)(
      "Powered by valgrind, written by Nepko");
   VG_(details_bug_reports_to)  (VG_BUGS_TO);
   VG_(details_avg_translation_sizeB) ( 200 );

   VG_(basic_tool_funcs)          (vf_post_clo_init,
                                   vf_instrument,
                                   vf_fini);
   VG_(needs_command_line_options)(vf_process_cmd_line_option,
                                   vf_print_usage,
                                   vf_print_debug_usage);
}